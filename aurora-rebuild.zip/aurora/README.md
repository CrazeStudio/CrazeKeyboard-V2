# CrazeKeyboard-V2 "Aurora" full UI rebuild (keyboard + app)

Copy `java/` over the repo's `java/` (merge, overwrite).

## Keyboard
- 22 key / space / panel / suggestion drawables (light + dark) rebuilt: 10dp tonal keys, pill spacebar,
  orange gradient active keys, flat panel, 22dp rounded suggestion bar.
- `values/craze-aurora-colors.xml`: new palette (aurora_light_* / aurora_dark_*).
- `values/craze-aurora-text-colors.xml`: new key/suggestion text colors.

## App
- `CrazeDashboardActivity.java` rewritten: gradient hero, setup checklist (enabled / selected),
  live playground, Aurora Light/Dark theme cards with accurate previews, settings rows, tinted haptics sliders.
  Same preferences, theme ids (3/4) and fragments as before.
- `CrazeDashboardTheme` refreshed; setup wizard recolored (dark) with pill-style action buttons.

## One manual step (avoids duplicate-resource build errors)
In `java/res/values/colors.xml`, delete these entries (now defined in craze-aurora-text-colors.xml):
key_text_color_lxx_light, key_functional_text_color_lxx_light, key_text_inactive_color_lxx_light,
key_hint_letter_color_lxx_light, language_on_spacebar_text_color_lxx_light, auto_correct_color_lxx_light,
typed_word_color_lxx_light, suggested_word_color_lxx_light, key_text_color_lxx_dark,
key_functional_text_color_lxx_dark, key_text_inactive_color_lxx_dark, key_hint_letter_color_lxx_dark,
language_on_spacebar_text_color_lxx_dark, auto_correct_color_lxx_dark, suggested_word_color_lxx_dark,
setup_background, setup_text_dark, setup_step_background, setup_welcome_video_margin_color.

Not changed: neon/synth presets, png key-preview/popup panels, emoji panel layout.
Untested: not compiled or run on a device.
